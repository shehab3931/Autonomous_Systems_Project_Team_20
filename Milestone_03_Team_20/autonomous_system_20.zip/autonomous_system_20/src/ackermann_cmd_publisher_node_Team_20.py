#!/usr/bin/env python

import rospy
from ackermann_msgs.msg import AckermannDrive

def publish_ackermann_commands():
    # Initialize the ROS node
    rospy.init_node('ackermann_cmd_publisher_node', anonymous=True)

    # Create a publisher for the ackermann_cmd topic
    ackermann_cmd_pub = rospy.Publisher('/ackermann_cmd', AckermannDrive, queue_size=10)

    # Set the loop rate (in Hz)
    rate = rospy.Rate(10)  # 10 Hz

    while not rospy.is_shutdown():
        # Create an AckermannDrive message
        ackermann_cmd = AckermannDrive()

        # Set the steering angle (in radians)
        ackermann_cmd.steering_angle = 0.3  # Example: 0.2 radians (about 11.5 degrees)

        # Set the steering angle velocity (in radians/second)
        ackermann_cmd.steering_angle_velocity = 0.1  # Example: 0.1 rad/s

        # Set the speed (in meters/second)
        ackermann_cmd.speed = -1.0  # Example: 1.0 m/s

        # Set the acceleration (in meters/second^2)
        ackermann_cmd.acceleration = 0.5  # Example: 0.5 m/s^2

        # Publish the Ackermann command
        ackermann_cmd_pub.publish(ackermann_cmd)

        # Log the command
        rospy.loginfo("Published Ackermann command: speed=%.2f m/s, steering_angle=%.2f rad", 
                      ackermann_cmd.speed, ackermann_cmd.steering_angle)

        # Sleep to maintain the loop rate
        rate.sleep()

if __name__ == '__main__':
    try:
        publish_ackermann_commands()
    except rospy.ROSInterruptException:
        pass
