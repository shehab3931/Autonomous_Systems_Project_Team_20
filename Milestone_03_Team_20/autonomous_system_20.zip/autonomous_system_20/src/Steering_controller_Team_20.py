#!/usr/bin/env python3

import rospy
import math
import tf
from gazebo_msgs.msg import ModelStates
from ackermann_msgs.msg import AckermannDrive
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Pose, Quaternion

class LaneStanleyController:
    def __init__(self):
        rospy.init_node('stanley_lane_controller')
        
        # Controller parameters
        self.gain = 1.0
        self.lane_slope = -1.0
        self.lane_intercept = 1.0
        
        # Vehicle state
        self.vehicle_pos = None
        self.vehicle_yaw = 0.0
        self.vehicle_vel = None
        self.lane_changed = False
        
        # ROS interfaces
        self.cmd_publisher = rospy.Publisher("/ackermann_cmd", AckermannDrive, queue_size=10)
        rospy.Subscriber("/gazebo/model_states", ModelStates, self.state_callback, queue_size=1)
        
        # Timing
        self.start_time = rospy.get_time()
        self.control_rate = rospy.Rate(30)  # 30Hz
        
        # Initialize lane visualization
        self.visualize_lane()
    
    def state_callback(self, msg):
        try:
            idx = msg.name.index("ackermann_vehicle")
            self.vehicle_pos = msg.pose[idx].position
            
            orientation = msg.pose[idx].orientation
            quat = (orientation.x, orientation.y, orientation.z, orientation.w)
            _, _, self.vehicle_yaw = tf.transformations.euler_from_quaternion(quat)
            
            self.vehicle_vel = msg.twist[idx].linear
        except ValueError:
            rospy.logwarn("Vehicle model not found in Gazebo states")
    
    def calculate_tracking_error(self):
        if self.vehicle_pos is None:
            return 0.0
            
        if abs(self.lane_slope) > 1e10:  # Vertical line case
            return self.vehicle_pos.x - (-self.lane_intercept / self.lane_slope)
        
        numerator = (self.lane_slope * self.vehicle_pos.x - 
                    self.vehicle_pos.y + self.lane_intercept)
        denominator = math.sqrt(self.lane_slope**2 + 1)
        return numerator / denominator
    
    def compute_steering_angle(self):
        speed = math.hypot(self.vehicle_vel.x, self.vehicle_vel.y) if self.vehicle_vel else 0.0
        cte = self.calculate_tracking_error()
        
        desired_heading = math.atan(self.lane_slope)
        heading_error = desired_heading - self.vehicle_yaw
        heading_error = math.atan2(math.sin(heading_error), math.cos(heading_error))
        
        cte_correction = math.atan2(self.gain * cte, speed + 1e-3)
        return heading_error + cte_correction
    
    def visualize_lane(self):
        # Implementation of lane visualization would go here
        pass
    
    def run(self):
        while not rospy.is_shutdown():
            if None in (self.vehicle_pos, self.vehicle_vel):
                rospy.loginfo_throttle(2, "Waiting for vehicle state...")
                self.control_rate.sleep()
                continue
            
            # Handle lane change after 7 seconds
            elapsed = rospy.get_time() - self.start_time
            if elapsed > 4.0 and not self.lane_changed:
                self.lane_intercept = 2.0
                self.lane_changed = True
                rospy.loginfo("Lane changed: intercept now 2.0")
                self.visualize_lane()
            
            # Create and publish control command
            cmd = AckermannDrive()
            cmd.steering_angle = self.compute_steering_angle()
            cmd.speed = 1.5  # Constant target speed
            self.cmd_publisher.publish(cmd)
            
            self.control_rate.sleep()

if __name__ == '__main__':
    try:
        controller = LaneStanleyController()
        controller.run()
    except rospy.ROSInterruptException:
        rospy.loginfo("Controller shutdown")
