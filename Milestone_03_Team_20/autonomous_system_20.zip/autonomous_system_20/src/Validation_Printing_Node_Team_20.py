#!/usr/bin/env python
import rospy  #get the libraries of the rospy
rospy.init_node('Validation_Printing_Node_Team_20')  #to initialize a ROS node
print ('Hello World From Team 20')

