#!/usr/bin/env python3
import rospy
import math
import tf
from gazebo_msgs.msg import ModelStates
from ackermann_msgs.msg import AckermannDrive
from geometry_msgs.msg import Pose, Quaternion
from gazebo_msgs.srv import SpawnModel

class AckermannController:
    def __init__(self):
        rospy.init_node("velocity_steering_controller")
        self.cmd_pub = rospy.Publisher("/ackermann_cmd", AckermannDrive, queue_size=10)
        rospy.Subscriber("/gazebo/model_states", ModelStates, self.model_state_callback, queue_size=1)

        self.kp, self.ki, self.kd = 2.0, 0.1, 0.1
        self.desired_velocity = 2.0
        self.dt = 0.005
        self.last_error = 0.0
        self.integral = 0.0

        self.stanley_gain = 1.0
        self.slope, self.intercept = -1.0, 1.0
        self.lane_switched = False

        self.vehicle_position = None
        self.vehicle_velocity = None
        self.vehicle_yaw = 0.0

        
        self.control_loop()

   

       
    def model_state_callback(self, data):
        try:
            index = data.name.index("ackermann_vehicle")
            pose = data.pose[index]
            twist = data.twist[index]
            self.vehicle_position = pose.position
            self.vehicle_velocity = twist.linear
            quaternion = (pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w)
            _, _, self.vehicle_yaw = tf.transformations.euler_from_quaternion(quaternion)
        except ValueError:
            pass

    def compute_cte(self):
        if abs(self.slope) > 1e10:
            return self.vehicle_position.x - (-self.intercept / self.slope)
        return (self.slope * self.vehicle_position.x - self.vehicle_position.y + self.intercept) / math.sqrt(self.slope**2 + 1)

    def control_loop(self):
        rate = rospy.Rate(10)
        cmd = AckermannDrive()
        start_time = rospy.get_time()

        while not rospy.is_shutdown():
            if self.vehicle_position is None or self.vehicle_velocity is None:
                rospy.loginfo_throttle(2, "Waiting for vehicle state...")
                rate.sleep()
                continue

            elapsed = rospy.get_time() - start_time
            if elapsed > 7.0 and not self.lane_switched:
                self.intercept = 0.0
                self.lane_switched = True
                rospy.loginfo(">>> Lane changed: intercept updated to 0.0")

            speed = math.hypot(self.vehicle_velocity.x, self.vehicle_velocity.y)
            error = self.desired_velocity - speed
            self.integral += error * self.dt
            derivative = (error - self.last_error) / self.dt
            control_speed = speed + (self.kp * error + self.ki * self.integral + self.kd * derivative) * self.dt
            self.last_error = error

            cte = self.compute_cte()
            path_yaw = math.atan(self.slope)
            heading_error = math.atan2(math.sin(path_yaw - self.vehicle_yaw), math.cos(path_yaw - self.vehicle_yaw))
            cte_correction = math.atan2(self.stanley_gain * cte, speed + 1e-3)

            cmd.speed = control_speed
            cmd.steering_angle = heading_error + cte_correction
            self.cmd_pub.publish(cmd)
            rate.sleep()

if __name__ == '__main__':
    try:
        AckermannController()
    except rospy.ROSInterruptException:
        pass

