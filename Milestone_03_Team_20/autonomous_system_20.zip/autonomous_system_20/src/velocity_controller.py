#!/usr/bin/env python3

import rospy
import math
from gazebo_msgs.msg import ModelStates
from ackermann_msgs.msg import AckermannDrive

def create_pid_controller():
    """Factory function to initialize PID controller parameters"""
    return {
        'kp': 1.5,
        'ki': 0.1,
        'kd': 0.01,
        'target': 2.0,
        'dt': 0.01,
        'integral': 0.0,
        'prev_error': 0.0
    }

def setup_ros_components():
    """Initialize ROS publishers and subscribers"""
    node = rospy.init_node("velocity_control_node")
    cmd_pub = rospy.Publisher("/ackermann_cmd", AckermannDrive, queue_size=1)
    return node, cmd_pub

def get_vehicle_velocity(model_states, vehicle_name="ackermann_vehicle"):
    """Extract vehicle velocity from model states"""
    try:
        idx = model_states.name.index(vehicle_name)
        return model_states.twist[idx].linear
    except ValueError:
        rospy.logwarn_once("Vehicle model not detected")
        return None

def calculate_pid_output(pid, current_velocity):
    """Compute PID control signal"""
    if current_velocity is None:
        return 0.0
    
    speed = math.sqrt(current_velocity.x**2 + current_velocity.y**2)
    error = pid['target'] - speed
    
    pid['integral'] += error * pid['dt']
    derivative = (error - pid['prev_error']) / pid['dt']
    pid['prev_error'] = error
    
    return (pid['kp'] * error + 
            pid['ki'] * pid['integral'] + 
            pid['kd'] * derivative)

def main_control_loop():
    """Execute the main control loop"""
    pid = create_pid_controller()
    _, command_publisher = setup_ros_components()
    rate = rospy.Rate(100)  # 100Hz
    
    def velocity_handler(model_states):
        nonlocal current_vel
        current_vel = get_vehicle_velocity(model_states)
        if current_vel:
            rospy.loginfo_throttle(1, f"Speed: {math.hypot(current_vel.x, current_vel.y):.2f} m/s")
    
    rospy.Subscriber("/gazebo/model_states", ModelStates, velocity_handler)
    current_vel = None
    
    while not rospy.is_shutdown():
        if current_vel:
            control_signal = calculate_pid_output(pid, current_vel)
            cmd = AckermannDrive()
            cmd.speed = math.hypot(current_vel.x, current_vel.y) + control_signal * pid['dt']
            cmd.steering_angle = 0.0
            command_publisher.publish(cmd)
        rate.sleep()

if __name__ == "__main__":
    try:
        main_control_loop()
    except rospy.ROSInterruptException:
        rospy.loginfo("Controller shutdown complete")
