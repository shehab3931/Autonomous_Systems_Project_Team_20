#!/usr/bin/env python3

import rospy
from ackermann_msgs.msg import AckermannDrive
import sys
import termios
import tty

class AckermannTeleop:
    def __init__(self):
        rospy.init_node('ackermann_teleop')
        self.cmd_pub = rospy.Publisher('/ackermann_cmd', AckermannDrive, queue_size=1)
        
        # Control parameters
        self.current_vel = 0.0
        self.current_steer = 0.0
        self.max_vel = 3.0
        self.max_steer = 0.5
        self.step_vel = 0.5
        self.step_steer = 0.1
        
        self.print_instructions()
        
    def print_instructions(self):
        print("\nAckermann Teleoperation Control")
        print("-----------------------------")
        print("w/s: Increase/Decrease speed")
        print("a/d: Steer left/right")
        print("space: Emergency stop")
        print("q: Quit program\n")
        
    def get_user_input(self):
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            return sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    
    def update_controls(self, key):
        if key == 'w':
            self.current_vel = min(self.current_vel + self.step_vel, self.max_vel)
        elif key == 's':
            self.current_vel = max(self.current_vel - self.step_vel, -self.max_vel)
        elif key == 'a':
            self.current_steer = min(self.current_steer + self.step_steer, self.max_steer)
        elif key == 'd':
            self.current_steer = max(self.current_steer - self.step_steer, -self.max_steer)
        elif key == ' ':
            self.current_vel = 0.0
            self.current_steer = 0.0
            print("! STOPPED !")
            
    def publish_command(self):
        cmd = AckermannDrive()
        cmd.speed = self.current_vel
        cmd.steering_angle = self.current_steer
        self.cmd_pub.publish(cmd)
        rospy.loginfo(f"Velocity: {self.current_vel:.1f} m/s | Steering: {self.current_steer:.1f} rad")
    
    def run(self):
        try:
            while not rospy.is_shutdown():
                key = self.get_user_input()
                if key == 'q':
                    print("\nExiting teleop...")
                    break
                
                self.update_controls(key)
                self.publish_command()
                
        except Exception as e:
            rospy.logerr(f"Error: {str(e)}")
        finally:
            # Send stop command before exiting
            stop_cmd = AckermannDrive()
            self.cmd_pub.publish(stop_cmd)

if __name__ == '__main__':
    controller = AckermannTeleop()
    controller.run()
